<script setup lang="ts">
import { useColumns } from "./columns";
import Calendar from "@iconify-icons/ri/calendar-2-line";

const { columns, filterTableData } = useColumns();
</script>

<template>
  <div class="flex justify-center items-center h-[640px]">
    <pure-table :data="filterTableData" :columns="columns">
      <template #nameHeader>
        <span class="flex items-center">
          <IconifyIconOffline :icon="Calendar" />
          日期
        </span>
      </template>
    </pure-table>
  </div>
</template>
